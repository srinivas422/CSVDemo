﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSVDemo
{
    public class Program
    {
        static void Main(string[] args)
        {

            using (StreamReader file1 = new StreamReader(@"C:\CSVFiles\SalesRecords1.csv"))
            using (StreamReader file2 = new StreamReader(@"C:\CSVFiles\SalesRecords2.csv"))
            {
                var newcsvfile = new StringBuilder();
                var headerline1 = file1.ReadLine();
                var headerline2 = file2.ReadLine();
                var header = string.Format("{0},{1},{2}", headerline1, "IsEqual?", headerline2);
                newcsvfile.AppendLine(header);

                while (!(file1.EndOfStream && file2.EndOfStream))
                {

                    var line1 = file1.ReadLine();
                    var line2 = file2.ReadLine();

                    var newLine = string.Format("{0},{1},{2}", line1, line1 == line2, line2);
                    newcsvfile.AppendLine(newLine);

                }
                File.WriteAllText(@"C:\CSVFiles\SalesRecords3.csv", newcsvfile.ToString());
            }
        }
    }
}
